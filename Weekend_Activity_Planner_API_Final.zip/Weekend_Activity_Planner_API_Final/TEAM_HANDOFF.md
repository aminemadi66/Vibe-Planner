# Team Handoff

## What is finished

- Weather city search
- 1 to 16 day weather forecast
- Weekend-only forecast
- Outdoor activity score from 0 to 100
- Google OAuth login flow
- Calendar connection status
- Busy periods
- Free time slots
- Calendar event list
- Create activity event
- Delete activity event

## What teammates need from this module

Base URL during local development:

```text
http://localhost:8000
```

For the recommender, the two most important calls are:

```text
GET /weather/weekend?city=Rome
GET /calendar/free-slots?...parameters...
```

After the user accepts a recommendation:

```text
POST /calendar/events
```

## Important

The ZIP intentionally does NOT contain real Google Client ID, Client Secret, or Google tokens. Those are private and should not be shared in the group chat or committed to GitHub.
