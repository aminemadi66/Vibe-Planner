# Weekend Activity Planner - Weather + Google Calendar API

This folder is the integration part of the Weekend Activity Planner project. It provides a FastAPI backend for:

- Weather lookup and weekend forecast
- Outdoor suitability score
- Google Calendar OAuth connection
- Busy/free-time detection
- Reading, creating, and deleting calendar events

## Quick start on Windows

1. Open this folder in VS Code.
2. Open a terminal in the project folder.
3. Run:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --default-timeout=100 -r requirements.txt
Copy-Item .env.example .env
```

4. Open `.env` and add your own Google OAuth credentials:

```text
GOOGLE_CLIENT_ID=YOUR_CLIENT_ID
GOOGLE_CLIENT_SECRET=YOUR_CLIENT_SECRET
GOOGLE_REDIRECT_URI=http://localhost:8000/calendar/oauth2callback
```

Never send or commit the real `.env` file.

5. Start the API:

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

6. Open Swagger:

```text
http://localhost:8000/docs
```

## Google Cloud setup

Before using Google Calendar:

1. Create/select a Google Cloud project.
2. Enable Google Calendar API.
3. Configure Google Auth Platform.
4. For testing, add the Google account as a Test User.
5. Create an OAuth client of type `Web application`.
6. Add this exact redirect URI:

```text
http://localhost:8000/calendar/oauth2callback
```

7. Put the Client ID and Client Secret in `.env`.
8. Restart the FastAPI server.
9. Open this URL directly in the browser:

```text
http://localhost:8000/calendar/auth
```

## Main endpoints

### Weather

```text
GET /weather/search?city=Tehran
GET /weather/forecast?city=Tehran&days=7
GET /weather/weekend?city=Tehran
```

The most useful endpoint for the recommendation system is `/weather/weekend`. It returns Saturday/Sunday weather plus an `outdoor_score` from 0 to 100.

### Google Calendar

```text
GET  /calendar/status
GET  /calendar/auth
GET  /calendar/busy
GET  /calendar/free-slots
GET  /calendar/events
POST /calendar/events
DELETE /calendar/events/{event_id}
POST /calendar/disconnect
```

Example activity creation body:

```json
{
  "summary": "Weekend Planner: Cycling",
  "start": "2026-08-15T10:00:00+02:00",
  "end": "2026-08-15T12:00:00+02:00",
  "timezone": "Europe/Rome",
  "location": "Villa Borghese, Rome",
  "description": "Recommended by Weekend Activity Planner"
}
```

## How it connects to the ML part

Recommended flow:

```text
User location
   -> Weather API
   -> Google Calendar free slots
   -> Filter by weather/time/budget
   -> ML recommender ranks activities
   -> User selects activity
   -> POST /calendar/events
```

The integration module is intentionally separate from the ML model so teammates can call it through HTTP without changing its internal code.

## Run tests

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

## Security note

Do not share `.env` or `.secrets/google_token.json`. Each teammate should use their own Google OAuth credentials for local testing.
