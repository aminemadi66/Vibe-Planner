from datetime import datetime

from app.services.calendar_slots import calculate_free_slots


def dt(value: str) -> datetime:
    return datetime.fromisoformat(value)


def test_free_slots_exclude_busy_periods():
    slots = calculate_free_slots(
        time_min=dt("2026-08-15T09:00:00+02:00"),
        time_max=dt("2026-08-15T20:00:00+02:00"),
        busy=[
            {"start": "2026-08-15T11:00:00+02:00", "end": "2026-08-15T13:00:00+02:00"},
            {"start": "2026-08-15T16:00:00+02:00", "end": "2026-08-15T17:00:00+02:00"},
        ],
        duration_minutes=90,
        timezone="Europe/Rome",
        day_start_hour=9,
        day_end_hour=20,
    )

    assert len(slots) == 3
    assert slots[0]["start"].startswith("2026-08-15T09:00:00")
    assert slots[0]["end"].startswith("2026-08-15T11:00:00")
    assert slots[1]["start"].startswith("2026-08-15T13:00:00")
    assert slots[2]["start"].startswith("2026-08-15T17:00:00")
