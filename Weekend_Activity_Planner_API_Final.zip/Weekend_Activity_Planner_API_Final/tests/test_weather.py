from datetime import date

from app.services.weather import next_weekend_dates, outdoor_score


def test_next_weekend_from_tuesday():
    saturday, sunday = next_weekend_dates(date(2026, 8, 11))
    assert saturday.isoformat() == "2026-08-15"
    assert sunday.isoformat() == "2026-08-16"


def test_outdoor_score_rewards_dry_comfortable_weather():
    nice = outdoor_score(25, 17, 5, 10, 1)
    storm = outdoor_score(25, 17, 90, 40, 95)
    assert nice > storm
    assert 0 <= storm <= 100
    assert 0 <= nice <= 100
