@echo off
setlocal
cd /d "%~dp0"
python -m venv .venv
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install --default-timeout=100 -r requirements.txt
if errorlevel 1 exit /b 1
if not exist .env copy .env.example .env >nul
echo.
echo Setup complete.
echo Edit .env and add your Google OAuth Client ID and Client Secret.
echo Then run run_windows.bat
