#!/usr/bin/env sh
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/python -m pip install --default-timeout=100 -r requirements.txt
[ -f .env ] || cp .env.example .env
echo "Setup complete. Edit .env, then run ./run_mac_linux.sh"
