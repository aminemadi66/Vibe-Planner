from __future__ import annotations

from datetime import datetime

from fastapi import FastAPI, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from starlette.middleware.sessions import SessionMiddleware

from app.config import settings
from app.schemas import CalendarEventCreate
from app.services import google_calendar, weather

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description="Weather and Google Calendar integration API for the Weekend Activity Planner.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.frontend_origins),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(
    SessionMiddleware,
    secret_key=settings.session_secret,
    same_site="lax",
    https_only=False,  # Set True behind HTTPS in production.
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/weather/search")
async def weather_search(city: str = Query(min_length=2), language: str = "en"):
    return await weather.geocode_city(city, language)


@app.get("/weather/forecast")
async def weather_forecast(
    city: str = Query(min_length=2),
    days: int = Query(default=7, ge=1, le=16),
    language: str = "en",
):
    return await weather.get_forecast(city, days, language)


@app.get("/weather/weekend")
async def weather_weekend(city: str = Query(min_length=2), language: str = "en"):
    return await weather.get_weekend_forecast(city, language)


@app.get("/calendar/status")
def calendar_status():
    return {"connected": google_calendar.is_connected()}


@app.get("/calendar/auth")
def calendar_auth(request: Request):
    url, state = google_calendar.authorization_url()
    request.session["google_oauth_state"] = state
    return RedirectResponse(url)


@app.get("/calendar/oauth2callback")
def calendar_callback(request: Request):
    expected_state = request.session.get("google_oauth_state")
    returned_state = request.query_params.get("state")
    if not expected_state or returned_state != expected_state:
        from fastapi import HTTPException

        raise HTTPException(status_code=400, detail="Invalid OAuth state")

    google_calendar.save_callback_credentials(str(request.url), expected_state)
    request.session.pop("google_oauth_state", None)
    return {"connected": True, "message": "Google Calendar connected successfully"}


@app.post("/calendar/disconnect")
def calendar_disconnect():
    google_calendar.disconnect()
    return {"connected": False}


@app.get("/calendar/busy")
def calendar_busy(
    time_min: datetime,
    time_max: datetime,
    calendar_id: str = "primary",
):
    busy = google_calendar.query_busy(time_min, time_max, calendar_id)
    return {"calendar_id": calendar_id, "busy": busy}


@app.get("/calendar/free-slots")
def calendar_free_slots(
    time_min: datetime,
    time_max: datetime,
    duration_minutes: int = Query(default=120, ge=15, le=1440),
    timezone: str = "UTC",
    day_start_hour: int = Query(default=9, ge=0, le=23),
    day_end_hour: int = Query(default=23, ge=1, le=24),
    calendar_id: str = "primary",
):
    busy = google_calendar.query_busy(time_min, time_max, calendar_id)
    slots = google_calendar.calculate_free_slots(
        time_min=time_min,
        time_max=time_max,
        busy=busy,
        duration_minutes=duration_minutes,
        timezone=timezone,
        day_start_hour=day_start_hour,
        day_end_hour=day_end_hour,
    )
    return {"calendar_id": calendar_id, "slots": slots}


@app.get("/calendar/events")
def calendar_events(
    time_min: datetime,
    time_max: datetime,
    calendar_id: str = "primary",
):
    return {
        "calendar_id": calendar_id,
        "events": google_calendar.list_events(time_min, time_max, calendar_id),
    }


@app.post("/calendar/events", status_code=201)
def calendar_create_event(event: CalendarEventCreate, calendar_id: str = "primary"):
    return google_calendar.create_event(event.model_dump(), calendar_id)


@app.delete("/calendar/events/{event_id}", status_code=204)
def calendar_delete_event(event_id: str, calendar_id: str = "primary"):
    google_calendar.delete_event(event_id, calendar_id)
    return None
