from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


def _csv_env(name: str, default: str) -> list[str]:
    value = os.getenv(name, default)
    return [item.strip() for item in value.split(",") if item.strip()]


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "Weekend Activity Planner Integrations")
    session_secret: str = os.getenv("SESSION_SECRET", "change-me-in-development")
    frontend_origins: tuple[str, ...] = tuple(
        _csv_env("FRONTEND_ORIGINS", "http://localhost:3000,http://localhost:5173")
    )

    google_client_id: str = os.getenv("GOOGLE_CLIENT_ID", "")
    google_client_secret: str = os.getenv("GOOGLE_CLIENT_SECRET", "")
    google_redirect_uri: str = os.getenv(
        "GOOGLE_REDIRECT_URI", "http://localhost:8000/calendar/oauth2callback"
    )
    google_token_file: Path = Path(
        os.getenv("GOOGLE_TOKEN_FILE", ".secrets/google_token.json")
    )


settings = Settings()
