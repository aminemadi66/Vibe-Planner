from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, model_validator


class CalendarEventCreate(BaseModel):
    summary: str = Field(min_length=1, max_length=300)
    start: datetime
    end: datetime
    timezone: str = "UTC"
    description: str | None = Field(default=None, max_length=8000)
    location: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def validate_times(self) -> "CalendarEventCreate":
        if self.start.tzinfo is None or self.end.tzinfo is None:
            raise ValueError("start and end must include a timezone offset")
        if self.end <= self.start:
            raise ValueError("end must be after start")
        return self


class FreeSlot(BaseModel):
    start: datetime
    end: datetime
    duration_minutes: int
