from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import HTTPException
from google.auth.transport.requests import Request as GoogleAuthRequest
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from app.config import settings
from app.services.calendar_slots import calculate_free_slots

SCOPES = [
    "https://www.googleapis.com/auth/calendar.events",
    "https://www.googleapis.com/auth/calendar.events.freebusy",
]


def _ensure_google_config() -> None:
    if not settings.google_client_id or not settings.google_client_secret:
        raise HTTPException(
            status_code=503,
            detail="Google Calendar OAuth is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.",
        )


def _client_config() -> dict[str, Any]:
    _ensure_google_config()
    return {
        "web": {
            "client_id": settings.google_client_id,
            "client_secret": settings.google_client_secret,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": [settings.google_redirect_uri],
        }
    }


def _allow_local_http_oauth() -> None:
    # OAuthlib blocks HTTP by default. Google permits loopback HTTP for local development.
    if settings.google_redirect_uri.startswith(("http://localhost", "http://127.0.0.1")):
        os.environ.setdefault("OAUTHLIB_INSECURE_TRANSPORT", "1")


def create_oauth_flow(state: str | None = None) -> Flow:
    _allow_local_http_oauth()
    flow = Flow.from_client_config(_client_config(), scopes=SCOPES, state=state)
    flow.redirect_uri = settings.google_redirect_uri
    return flow


def authorization_url() -> tuple[str, str]:
    flow = create_oauth_flow()
    url, state = flow.authorization_url(
        access_type="offline",
        include_granted_scopes="true",
        prompt="consent",
    )
    return url, state


def _save_credentials(credentials: Credentials) -> None:
    token_path: Path = settings.google_token_file
    token_path.parent.mkdir(parents=True, exist_ok=True)
    token_path.write_text(credentials.to_json(), encoding="utf-8")
    try:
        token_path.chmod(0o600)
    except OSError:
        pass


def save_callback_credentials(authorization_response: str, state: str) -> None:
    flow = create_oauth_flow(state=state)
    flow.fetch_token(authorization_response=authorization_response)
    _save_credentials(flow.credentials)


def disconnect() -> None:
    try:
        settings.google_token_file.unlink(missing_ok=True)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Could not remove token: {exc}") from exc


def get_credentials() -> Credentials:
    token_path = settings.google_token_file
    if not token_path.exists():
        raise HTTPException(status_code=401, detail="Google Calendar is not connected")

    try:
        info = json.loads(token_path.read_text(encoding="utf-8"))
        credentials = Credentials.from_authorized_user_info(info, scopes=SCOPES)
    except (ValueError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=401, detail="Stored Google token is invalid") from exc

    if credentials.expired and credentials.refresh_token:
        try:
            credentials.refresh(GoogleAuthRequest())
            _save_credentials(credentials)
        except Exception as exc:
            raise HTTPException(status_code=401, detail="Google token refresh failed") from exc

    if not credentials.valid:
        raise HTTPException(status_code=401, detail="Google Calendar authorization is invalid")
    return credentials


def is_connected() -> bool:
    try:
        get_credentials()
        return True
    except HTTPException:
        return False


def _service():
    return build("calendar", "v3", credentials=get_credentials(), cache_discovery=False)


def _google_error(exc: HttpError) -> HTTPException:
    status = getattr(exc.resp, "status", 502)
    if status in {401, 403}:
        return HTTPException(status_code=status, detail="Google Calendar authorization failed")
    if status == 404:
        return HTTPException(status_code=404, detail="Google Calendar resource not found")
    return HTTPException(status_code=502, detail="Google Calendar API request failed")


def query_busy(time_min: datetime, time_max: datetime, calendar_id: str = "primary") -> list[dict[str, str]]:
    if time_min.tzinfo is None or time_max.tzinfo is None:
        raise HTTPException(status_code=400, detail="time_min and time_max must include timezone offsets")
    if time_max <= time_min:
        raise HTTPException(status_code=400, detail="time_max must be after time_min")

    body = {
        "timeMin": time_min.isoformat(),
        "timeMax": time_max.isoformat(),
        "items": [{"id": calendar_id}],
    }
    try:
        response = _service().freebusy().query(body=body).execute()
    except HttpError as exc:
        raise _google_error(exc) from exc

    calendar = response.get("calendars", {}).get(calendar_id, {})
    if calendar.get("errors"):
        raise HTTPException(status_code=502, detail={"calendar_errors": calendar["errors"]})
    return calendar.get("busy", [])


def list_events(time_min: datetime, time_max: datetime, calendar_id: str = "primary") -> list[dict[str, Any]]:
    try:
        result = (
            _service()
            .events()
            .list(
                calendarId=calendar_id,
                timeMin=time_min.isoformat(),
                timeMax=time_max.isoformat(),
                singleEvents=True,
                orderBy="startTime",
                maxResults=250,
            )
            .execute()
        )
    except HttpError as exc:
        raise _google_error(exc) from exc

    events = []
    for item in result.get("items", []):
        events.append(
            {
                "id": item.get("id"),
                "summary": item.get("summary", "(untitled)"),
                "start": item.get("start", {}).get("dateTime") or item.get("start", {}).get("date"),
                "end": item.get("end", {}).get("dateTime") or item.get("end", {}).get("date"),
                "location": item.get("location"),
                "html_link": item.get("htmlLink"),
            }
        )
    return events


def create_event(event: dict[str, Any], calendar_id: str = "primary") -> dict[str, Any]:
    body = {
        "summary": event["summary"],
        "start": {"dateTime": event["start"].isoformat(), "timeZone": event["timezone"]},
        "end": {"dateTime": event["end"].isoformat(), "timeZone": event["timezone"]},
    }
    if event.get("description"):
        body["description"] = event["description"]
    if event.get("location"):
        body["location"] = event["location"]

    try:
        created = _service().events().insert(calendarId=calendar_id, body=body).execute()
    except HttpError as exc:
        raise _google_error(exc) from exc

    return {
        "id": created.get("id"),
        "summary": created.get("summary"),
        "start": created.get("start"),
        "end": created.get("end"),
        "html_link": created.get("htmlLink"),
    }


def delete_event(event_id: str, calendar_id: str = "primary") -> None:
    try:
        _service().events().delete(calendarId=calendar_id, eventId=event_id).execute()
    except HttpError as exc:
        raise _google_error(exc) from exc
