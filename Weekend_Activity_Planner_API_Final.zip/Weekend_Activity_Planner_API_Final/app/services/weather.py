from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

import httpx
from fastapi import HTTPException

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

# WMO weather interpretation codes used by Open-Meteo.
WEATHER_CODES = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    56: "Light freezing drizzle",
    57: "Dense freezing drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Slight snowfall",
    73: "Moderate snowfall",
    75: "Heavy snowfall",
    77: "Snow grains",
    80: "Slight rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    85: "Slight snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with slight hail",
    99: "Thunderstorm with heavy hail",
}


async def geocode_city(city: str, language: str = "en") -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.get(
            GEOCODING_URL,
            params={"name": city, "count": 1, "language": language, "format": "json"},
        )
    if response.is_error:
        raise HTTPException(status_code=502, detail="Weather geocoding provider failed")

    results = response.json().get("results", [])
    if not results:
        raise HTTPException(status_code=404, detail=f"Location not found: {city}")

    item = results[0]
    return {
        "name": item["name"],
        "country": item.get("country"),
        "country_code": item.get("country_code"),
        "admin1": item.get("admin1"),
        "latitude": item["latitude"],
        "longitude": item["longitude"],
        "timezone": item.get("timezone", "UTC"),
    }


def outdoor_score(
    temp_max: float,
    temp_min: float,
    precipitation_probability: float,
    wind_speed_max: float,
    weather_code: int,
) -> int:
    """Simple heuristic score for ranking outdoor weekend activities (0-100)."""
    avg_temp = (temp_max + temp_min) / 2
    score = 100.0

    # Comfortable outdoor band: roughly 12-27 C.
    if avg_temp < 12:
        score -= min(35, (12 - avg_temp) * 2.5)
    elif avg_temp > 27:
        score -= min(35, (avg_temp - 27) * 2.5)

    score -= precipitation_probability * 0.45
    if wind_speed_max > 25:
        score -= min(25, (wind_speed_max - 25) * 0.9)

    if weather_code in {95, 96, 99}:
        score -= 30
    elif weather_code in {65, 67, 75, 82, 86}:
        score -= 18

    return max(0, min(100, round(score)))


async def get_forecast(city: str, days: int = 7, language: str = "en") -> dict[str, Any]:
    location = await geocode_city(city, language)
    days = max(1, min(days, 16))

    params = {
        "latitude": location["latitude"],
        "longitude": location["longitude"],
        "timezone": location["timezone"],
        "forecast_days": days,
        "daily": ",".join(
            [
                "weather_code",
                "temperature_2m_max",
                "temperature_2m_min",
                "apparent_temperature_max",
                "apparent_temperature_min",
                "precipitation_probability_max",
                "precipitation_sum",
                "wind_speed_10m_max",
                "sunrise",
                "sunset",
            ]
        ),
    }

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.get(FORECAST_URL, params=params)
    if response.is_error:
        raise HTTPException(status_code=502, detail="Weather forecast provider failed")

    payload = response.json()
    daily = payload.get("daily", {})
    result = []
    for i, day in enumerate(daily.get("time", [])):
        code = int(daily["weather_code"][i])
        temp_max = float(daily["temperature_2m_max"][i])
        temp_min = float(daily["temperature_2m_min"][i])
        rain_probability = float(daily["precipitation_probability_max"][i] or 0)
        wind_max = float(daily["wind_speed_10m_max"][i] or 0)
        result.append(
            {
                "date": day,
                "weather_code": code,
                "condition": WEATHER_CODES.get(code, "Unknown"),
                "temperature_max_c": temp_max,
                "temperature_min_c": temp_min,
                "apparent_temperature_max_c": daily["apparent_temperature_max"][i],
                "apparent_temperature_min_c": daily["apparent_temperature_min"][i],
                "precipitation_probability_max_percent": rain_probability,
                "precipitation_sum_mm": daily["precipitation_sum"][i],
                "wind_speed_max_kmh": wind_max,
                "sunrise": daily["sunrise"][i],
                "sunset": daily["sunset"][i],
                "outdoor_score": outdoor_score(
                    temp_max, temp_min, rain_probability, wind_max, code
                ),
            }
        )

    return {"location": location, "days": result}


def next_weekend_dates(today: date | None = None) -> tuple[date, date]:
    today = today or datetime.now().date()
    # Monday=0 ... Saturday=5, Sunday=6. If today is Saturday/Sunday, use this weekend.
    days_until_saturday = (5 - today.weekday()) % 7
    saturday = today + timedelta(days=days_until_saturday)
    sunday = saturday + timedelta(days=1)
    return saturday, sunday


async def get_weekend_forecast(city: str, language: str = "en") -> dict[str, Any]:
    # 16 days is the provider maximum and comfortably includes the next weekend.
    forecast = await get_forecast(city=city, days=16, language=language)
    local_today = datetime.now(ZoneInfo(forecast["location"]["timezone"])).date()
    saturday, sunday = next_weekend_dates(local_today)
    wanted = {saturday.isoformat(), sunday.isoformat()}
    forecast["days"] = [day for day in forecast["days"] if day["date"] in wanted]
    return forecast
