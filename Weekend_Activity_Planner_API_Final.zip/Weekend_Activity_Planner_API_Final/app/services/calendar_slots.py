from __future__ import annotations

from datetime import datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import HTTPException


def _parse_google_dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _merge_intervals(intervals: list[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    if not intervals:
        return []
    intervals = sorted(intervals, key=lambda item: item[0])
    merged = [intervals[0]]
    for start, end in intervals[1:]:
        last_start, last_end = merged[-1]
        if start <= last_end:
            merged[-1] = (last_start, max(last_end, end))
        else:
            merged.append((start, end))
    return merged


def calculate_free_slots(
    time_min: datetime,
    time_max: datetime,
    busy: list[dict[str, str]],
    duration_minutes: int,
    timezone: str,
    day_start_hour: int,
    day_end_hour: int,
) -> list[dict[str, Any]]:
    if time_min.tzinfo is None or time_max.tzinfo is None:
        raise HTTPException(status_code=400, detail="time_min and time_max must include timezone offsets")
    if time_max <= time_min:
        raise HTTPException(status_code=400, detail="time_max must be after time_min")
    if duration_minutes < 15 or duration_minutes > 1440:
        raise HTTPException(status_code=400, detail="duration_minutes must be between 15 and 1440")
    if not (0 <= day_start_hour <= 23 and 1 <= day_end_hour <= 24 and day_start_hour < day_end_hour):
        raise HTTPException(status_code=400, detail="Invalid daily time window")

    try:
        tz = ZoneInfo(timezone)
    except ZoneInfoNotFoundError as exc:
        raise HTTPException(status_code=400, detail=f"Unknown timezone: {timezone}") from exc

    query_start = time_min.astimezone(tz)
    query_end = time_max.astimezone(tz)
    busy_intervals = _merge_intervals(
        [
            (_parse_google_dt(item["start"]).astimezone(tz), _parse_google_dt(item["end"]).astimezone(tz))
            for item in busy
        ]
    )

    duration = timedelta(minutes=duration_minutes)
    slots: list[dict[str, Any]] = []
    current_date = query_start.date()

    while current_date <= query_end.date():
        window_start = datetime.combine(current_date, time(day_start_hour, 0), tzinfo=tz)
        if day_end_hour == 24:
            window_end = datetime.combine(current_date + timedelta(days=1), time(0, 0), tzinfo=tz)
        else:
            window_end = datetime.combine(current_date, time(day_end_hour, 0), tzinfo=tz)

        window_start = max(window_start, query_start)
        window_end = min(window_end, query_end)
        if window_end > window_start:
            cursor = window_start
            for busy_start, busy_end in busy_intervals:
                if busy_end <= window_start or busy_start >= window_end:
                    continue
                clipped_start = max(busy_start, window_start)
                clipped_end = min(busy_end, window_end)
                if clipped_start - cursor >= duration:
                    slots.append(
                        {
                            "start": cursor.isoformat(),
                            "end": clipped_start.isoformat(),
                            "duration_minutes": int((clipped_start - cursor).total_seconds() // 60),
                        }
                    )
                cursor = max(cursor, clipped_end)
            if window_end - cursor >= duration:
                slots.append(
                    {
                        "start": cursor.isoformat(),
                        "end": window_end.isoformat(),
                        "duration_minutes": int((window_end - cursor).total_seconds() // 60),
                    }
                )

        current_date += timedelta(days=1)

    return slots
