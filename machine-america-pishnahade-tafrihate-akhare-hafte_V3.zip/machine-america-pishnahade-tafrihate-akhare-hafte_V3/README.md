# Weekend Activity Planner — United States

Competition-ready seed data for a personalized weekend activity recommender. Generated **2026-08-04T10:18:36.896526+00:00**. It contains **11,630** named OSM places across **12** major US cities, plus 1,000 clearly marked synthetic user profiles and 15,695 correlated synthetic interactions.

## Files
- `activities.csv`: real, named mapped places; one OSM element per row after deduplication.
- `users.csv`, `interactions.csv`: artificial ML training signals, all `synthetic=true`; preferences, budget, group, accessibility, city and indoor/outdoor fit drive sampling.
- `activity_categories.csv`, `weather_suitability.csv`: semantics and simple context rules.
- `weekend_activity_planner_us.sqlite`: same data in SQLite.
- `data_dictionary.csv`, `validation_report.json`, `SOURCES_LICENSE.md`: schema, checks, provenance/license.
- `scripts/build_weekend_activity_planner_us.py`: reproducible builder; `scripts/baseline_recommender.py`: starter.

## Quick start
```bash
python scripts/baseline_recommender.py --city Seattle --budget 30 --weather rain --categories museum,gallery
```

## Running the Flask + FastAPI web app together

The `app.py` Flask app (pages + `/api/weather`) and the
`Weekend_Activity_Planner_API_Final/` FastAPI service (real weather +
Google Calendar) are two separate processes. `app.py` now launches the
FastAPI service for you automatically, using **paths computed from its own
location** — no hardcoded machine-specific path to edit.

1. Install the FastAPI service's own dependencies (separate env, per its README):
   ```bash
   cd Weekend_Activity_Planner_API_Final
   python -m venv .venv
   # Windows: .venv\Scripts\python.exe -m pip install -r requirements.txt
   # macOS/Linux:
   .venv/bin/python -m pip install -r requirements.txt
   cp .env.example .env   # or Copy-Item on Windows
   cd ..
   ```
2. Install the Flask app's dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run everything from the project root:
   ```bash
   python app.py
   ```
   This starts FastAPI on `http://127.0.0.1:8000` (waiting until it answers
   `/health` before continuing) and Flask on `http://127.0.0.1:5000`.
4. Open `http://127.0.0.1:5000`, and check `http://127.0.0.1:5000/test-api`
   to confirm Flask can reach FastAPI.

If `Weekend_Activity_Planner_API_Final/.venv` doesn't exist yet, `app.py`
falls back to running FastAPI with the same interpreter running Flask —
in that case make sure you `pip install -r Weekend_Activity_Planner_API_Final/requirements.txt`
into that same environment too.

## Important limits
OSM is community-maintained: categories, accessibility, contact details and opening hours can be incomplete/outdated. City assignment uses collection bounding boxes rather than a reverse-geocoded municipal boundary. Coordinates for ways/relations are OSM centers and may not be entrances. Prices and durations are explicit heuristic estimates; never treat them as venue facts. Confirm availability, fees, safety, and accessibility with the venue. This is a point-in-time extract—not a complete US inventory.

## License / attribution
See `SOURCES_LICENSE.md`; public use requires OSM attribution and ODbL compliance.
