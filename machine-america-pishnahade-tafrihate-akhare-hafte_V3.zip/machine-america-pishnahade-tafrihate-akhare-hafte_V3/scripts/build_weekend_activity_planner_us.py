#!/usr/bin/env python3
"""Build Weekend Activity Planner US dataset from OpenStreetMap via Overpass.
Public source: © OpenStreetMap contributors, ODbL 1.0. Re-run to refresh.
Requires Python stdlib and network access.
"""
import csv, json, os, re, time, math, sqlite3, random, hashlib, urllib.request, urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime, timezone, timedelta

OUT=Path('/tasklet/agent/home/weekend_activity_planner_us')
OUT.mkdir(parents=True,exist_ok=True)
UA='WeekendActivityPlannerDataset/1.0 (educational dataset; contact: dataset-builder@example.invalid)'
# metro-oriented bounded areas, selected major US cities
CITIES=[
 ('New York','NY',40.68,-74.05,40.84,-73.88), ('Los Angeles','CA',33.92,-118.55,34.15,-118.20),
 ('Chicago','IL',41.75,-87.80,42.02,-87.52), ('Houston','TX',29.60,-95.55,29.90,-95.20),
 ('Phoenix','AZ',33.40,-112.13,33.53,-112.00), ('Philadelphia','PA',39.93,-75.23,40.03,-75.10),
 ('San Antonio','TX',29.40,-98.53,29.51,-98.40), ('San Diego','CA',32.70,-117.20,32.82,-117.08),
 ('Dallas','TX',32.73,-96.84,32.84,-96.70), ('San Francisco','CA',37.74,-122.49,37.81,-122.40),
 ('Seattle','WA',47.58,-122.38,47.67,-122.29), ('Boston','MA',42.33,-71.13,42.38,-71.05),
]
# category mapping, tag key/value combos; broad sports retained as sports/fitness
MAP={
 ('leisure','park'):('park','urban_park','outdoor'),('leisure','nature_reserve'):('hiking/nature','nature_reserve','outdoor'),
 ('leisure','fitness_centre'):('sports/fitness','fitness_centre','indoor'),('leisure','sports_centre'):('sports/fitness','sports_centre','mixed'),
 ('leisure','stadium'):('sports/fitness','stadium','mixed'),('leisure','swimming_pool'):('sports/fitness','swimming_pool','mixed'),
 ('leisure','golf_course'):('sports/fitness','golf_course','outdoor'),('leisure','miniature_golf'):('amusement','mini_golf','outdoor'),
 ('leisure','playground'):('amusement','playground','outdoor'),('leisure','track'):('sports/fitness','track','outdoor'),
 ('amenity','museum'):('museum','museum','indoor'),('tourism','museum'):('museum','museum','indoor'),('amenity','cinema'):('cinema','cinema','indoor'),
 ('amenity','theatre'):('theatre','theatre','indoor'),('amenity','arts_centre'):('gallery','arts_centre','indoor'),('amenity','library'):('library','library','indoor'),
 ('tourism','gallery'):('gallery','gallery','indoor'),('tourism','zoo'):('zoo','zoo','outdoor'),('amenity','zoo'):('zoo','zoo','outdoor'),
 ('tourism','aquarium'):('aquarium','aquarium','indoor'),('tourism','attraction'):('attraction','attraction','mixed'),
 ('tourism','theme_park'):('amusement','theme_park','outdoor'),('leisure','amusement_arcade'):('amusement','arcade','indoor'),
 ('natural','beach'):('hiking/nature','beach','outdoor'),('natural','peak'):('hiking/nature','peak','outdoor'),
 ('tourism','viewpoint'):('attraction','viewpoint','outdoor'),
}
VALUES={k:sorted({v for (kk,v) in MAP if kk==k}) for k in set(k for k,v in MAP)}
def fetch(city):
 name,state,s,w,n,e=city
 clauses=''.join(f'nwr["{key}"~"^({"|".join(vals)})$"]["name"]({s},{w},{n},{e});' for key,vals in VALUES.items())
 q='[out:json][timeout:180];('+clauses+');out center tags;'
 data=urllib.parse.urlencode({'data':q}).encode()
 errs=[]
 for endpoint in ['https://maps.mail.ru/osm/tools/overpass/api/interpreter','https://overpass.private.coffee/api/interpreter','https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter']:
  try:
   req=urllib.request.Request(endpoint,data=data,headers={'User-Agent':UA,'Content-Type':'application/x-www-form-urlencoded'})
   with urllib.request.urlopen(req,timeout=240) as r: return json.load(r),endpoint
  except Exception as ex: errs.append(f'{endpoint}: {ex}')
 # Small bboxes can be obtained from the official OSM map API if Overpass is busy.
 try:
  bbox=f"{w},{s},{e},{n}"; req=urllib.request.Request('https://api.openstreetmap.org/api/0.6/map?bbox='+bbox,headers={'User-Agent':UA})
  with urllib.request.urlopen(req,timeout=240) as r: root=ET.fromstring(r.read())
  nodes={x.attrib['id']:(float(x.attrib['lat']),float(x.attrib['lon'])) for x in root.findall('node')}
  els=[]
  for x in list(root):
   tags={z.attrib['k']:z.attrib['v'] for z in x.findall('tag')}
   if not tags.get('name'): continue
   if x.tag=='node': els.append({'type':'node','id':int(x.attrib['id']),'lat':float(x.attrib['lat']),'lon':float(x.attrib['lon']),'tags':tags})
   elif x.tag=='way':
    pts=[nodes[z.attrib['ref']] for z in x.findall('nd') if z.attrib['ref'] in nodes]
    if pts: els.append({'type':'way','id':int(x.attrib['id']),'center':{'lat':sum(z[0] for z in pts)/len(pts),'lon':sum(z[1] for z in pts)/len(pts)},'tags':tags})
  return {'elements':els},'official OSM API map endpoint (Overpass fallback)'
 except Exception as ex: errs.append(f'official OSM API: {ex}')
 raise RuntimeError('; '.join(errs))
def esc(x): return (x or '').replace('\n',' ').replace('\r',' ').strip()
def cleanname(x): return re.sub(r'\s+',' ',esc(x))
def choose(tags):
 for k in ('amenity','tourism','leisure','natural'):
  if (k,tags.get(k)) in MAP:return MAP[(k,tags[k])]
 return None
def cost(cat,sub,tags):
 # Explicitly model-derived estimates, never real ticket assertions
 base={'park':(0,0),'library':(0,0),'hiking/nature':(0,0),'museum':(10,30),'cinema':(12,25),'theatre':(20,80),'zoo':(18,45),'aquarium':(20,45),'gallery':(0,20),'sports/fitness':(0,25),'attraction':(0,25),'amusement':(0,35)}[cat]
 if tags.get('fee','').lower() in ('no','false','0'): return 0,0,False
 return *base,True
def dur(cat): return {'park':90,'library':75,'hiking/nature':150,'museum':120,'cinema':135,'theatre':150,'zoo':180,'aquarium':120,'gallery':75,'sports/fitness':90,'attraction':90,'amusement':120}[cat]
def fget(t,k):return esc(t.get(k,''))
def main():
 rows=[]; calls=[]
 for ix,city in enumerate(CITIES):
  print('fetching',city[:2],flush=True)
  cache=OUT/'raw_overpass'; cache.mkdir(exist_ok=True); cp=cache/(city[0].lower().replace(' ','_')+'.json')
  if cp.exists(): data=json.loads(cp.read_text()); endpoint='cached local Overpass response'
  else:
   data,endpoint=fetch(city); cp.write_text(json.dumps(data))
  calls.append({'city':city[0],'state':city[1],'bbox':city[2:],'endpoint':endpoint,'elements_returned':len(data.get('elements',[]))})
  for el in data.get('elements',[]):
   t=el.get('tags',{}); m=choose(t); name=cleanname(t.get('name',''))
   lat=el.get('lat',el.get('center',{}).get('lat')); lon=el.get('lon',el.get('center',{}).get('lon'))
   if not m or not name or lat is None or lon is None: continue
   cat,sub,io=m; mn,mx,estimated=cost(cat,sub,t)
   wheelchair=fget(t,'wheelchair').lower() or 'unknown'
   if wheelchair not in ('yes','no','limited','unknown'):wheelchair='unknown'
   kids='yes' if cat in ('park','zoo','aquarium','amusement','cinema','library') or sub=='playground' else 'unknown'
   group='large' if cat in ('park','sports/fitness','zoo','amusement','attraction') else 'small_to_large'
   oid=f"osm_{el['type']}_{el['id']}"
   tags_count=len(t); q=round(min(1, .45+.04*min(tags_count,10)+(.1 if fget(t,'website') else 0)+(.05 if fget(t,'opening_hours') else 0)),2)
   rows.append(dict(activity_id=oid,name=name,category=cat,subcategory=sub,city=city[0],state=city[1],lat=round(float(lat),6),lon=round(float(lon),6),indoor_outdoor=io,estimated_cost_usd_min=mn,estimated_cost_usd_max=mx,is_estimated=str(estimated).lower(),typical_duration_min=dur(cat),group_suitability=group,family_kids_suitable=kids,wheelchair=wheelchair,website=fget(t,'website'),phone=fget(t,'phone'),opening_hours=fget(t,'opening_hours'),source='OpenStreetMap',source_id=f"{el['type']}/{el['id']}",source_url=f"https://www.openstreetmap.org/{el['type']}/{el['id']}",data_quality_score=q))
  time.sleep(15)
 # stable duplicate handling: primary OSM identity then same normalized name/category/rounded coordinates
 unique={}; dedup=[]
 for r in rows:
  key=(r['activity_id'])
  if key not in unique: unique[key]=r
 for r in unique.values():
  key=(re.sub(r'\W','',r['name'].lower()),r['category'],round(r['lat'],4),round(r['lon'],4))
  if key not in dedup: dedup.append(key); unique_key=True
 # the above needs rows output associated
 seen=set(); final=[]
 for r in unique.values():
  key=(re.sub(r'\W','',r['name'].lower()),r['category'],round(r['lat'],4),round(r['lon'],4))
  if key not in seen:seen.add(key);final.append(r)
 final.sort(key=lambda x:(x['city'],x['category'],x['name'].casefold()))
 fields=list(final[0])
 with open(OUT/'activities.csv','w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(final)
 # categories
 cats=[]
 for c in sorted(set(x['category'] for x in final)):
  cats.append({'category':c,'description':{'park':'Public parks and green spaces','museum':'Museums and exhibits','attraction':'Visitor attractions, viewpoints, and public art','cinema':'Movie theaters','theatre':'Theaters and performance venues','zoo':'Zoos','aquarium':'Aquariums','gallery':'Galleries and arts centers','library':'Libraries','sports/fitness':'Sports, fitness and recreation','hiking/nature':'Nature reserves, beaches and natural destinations','amusement':'Playgrounds, arcades, theme parks and mini golf'}[c],'default_duration_min':dur(c),'cost_values_are_estimated':'true'})
 with open(OUT/'activity_categories.csv','w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cats[0]);w.writeheader();w.writerows(cats)
 weather=[
 {'weather_condition':'sunny','preferred_indoor_outdoor':'outdoor','recommendation_adjustment':'0.20','note':'Favor parks, nature, zoos, outdoor attractions.'},
 {'weather_condition':'rain','preferred_indoor_outdoor':'indoor','recommendation_adjustment':'0.25','note':'Favor museums, cinema, theatre, libraries, galleries.'},
 {'weather_condition':'snow','preferred_indoor_outdoor':'indoor','recommendation_adjustment':'0.25','note':'Favor indoor venues; confirm local access.'},
 {'weather_condition':'hot','preferred_indoor_outdoor':'indoor','recommendation_adjustment':'0.15','note':'Favor air-conditioned venues; outdoor water/early options may suit.'},
 {'weather_condition':'mild','preferred_indoor_outdoor':'mixed','recommendation_adjustment':'0.10','note':'No strong indoor/outdoor constraint.'}]
 with open(OUT/'weather_suitability.csv','w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=weather[0]);w.writeheader();w.writerows(weather)
 # correlated synthetic users/interactions
 rng=random.Random(20260804); categories=sorted(set(x['category'] for x in final)); bycity={}
 for r in final:bycity.setdefault(r['city'],[]).append(r)
 users=[]; interactions=[]
 for i in range(1000):
  city=rng.choice(list(bycity)); prefs=rng.sample(categories,rng.randint(2,4)); budget=rng.choice([0,15,25,40,75,120]); group=rng.choice(['solo','couple','family','friends']); indoor=rng.choice(['indoor','outdoor','mixed']); kids=group=='family'
  u={'user_id':f'syn_u{i+1:04d}','home_city':city,'home_state':next(x['state'] for x in final if x['city']==city),'preferred_categories':'|'.join(prefs),'budget_usd':budget,'group_type':group,'has_kids':str(kids).lower(),'indoor_outdoor_preference':indoor,'wheelchair_need':str(rng.random()<.07).lower(),'synthetic':'true'}; users.append(u)
  candidates=bycity[city]
  scored=[]
  for a in candidates:
   s=1.0+(2.3 if a['category'] in prefs else 0)+(0.8 if indoor=='mixed' or a['indoor_outdoor']==indoor or a['indoor_outdoor']=='mixed' else 0)+(1 if kids and a['family_kids_suitable']=='yes' else 0)+(0.8 if budget>=float(a['estimated_cost_usd_max']) else -1.2)+(0.35*a['data_quality_score'])
   if u['wheelchair_need']=='true':s+=.7 if a['wheelchair']=='yes' else -.35
   scored.append((max(.05,s),a))
  # weighted choices; ranks/ratings reflect fit, contextual weather
  selected=[]
  for _ in range(rng.randint(12,20)):
   a=rng.choices([x[1] for x in scored],weights=[x[0] for x in scored],k=1)[0]
   if a['activity_id'] not in {z['activity_id'] for z in selected}:selected.append(a)
  for a in selected:
   fit=next(s for s,x in scored if x['activity_id']==a['activity_id']); rating=max(1,min(5,round(2.3+fit*.65+rng.gauss(0,.55))))
   interactions.append({'interaction_id':f'syn_i{len(interactions)+1:06d}','user_id':u['user_id'],'activity_id':a['activity_id'],'interaction_type':rng.choices(['view','save','rating','visit'],[.25,.2,.3,.25])[0],'rating':rating,'event_date':(datetime(2025,1,1)+timedelta(days=rng.randrange(580))).date().isoformat(),'weather_context':rng.choice(['sunny','rain','mild','hot']),'group_type':group,'synthetic':'true'})
 for fn,data in [('users.csv',users),('interactions.csv',interactions)]:
  with open(OUT/fn,'w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=data[0]);w.writeheader();w.writerows(data)
 # dictionary
 dictionary=[]
 for filename, data in [('activities.csv',final),('users.csv',users),('interactions.csv',interactions),('activity_categories.csv',cats),('weather_suitability.csv',weather)]:
  for col in data[0]:dictionary.append({'file':filename,'field':col,'description':{'activity_id':'Stable OpenStreetMap-derived activity identifier','is_estimated':'True if price is a model/default estimate, not observed venue pricing','synthetic':'Always true: generated training data, not real user behavior','source_id':'OSM element type/id','data_quality_score':'0–1 completeness heuristic, not an editorial rating'}.get(col,'See README for definition and allowed values.')})
 with open(OUT/'data_dictionary.csv','w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=dictionary[0]);w.writeheader();w.writerows(dictionary)
 # sqlite
 db=sqlite3.connect(OUT/'weekend_activity_planner_us.sqlite')
 for fn,data in [('activities',final),('users',users),('interactions',interactions),('activity_categories',cats),('weather_suitability',weather)]:
  cols=list(data[0]); db.execute(f'DROP TABLE IF EXISTS "{fn}"');db.execute('CREATE TABLE "%s" (%s)'%(fn,','.join('"%s" TEXT'%c for c in cols)));db.executemany('INSERT INTO "%s" VALUES (%s)'%(fn,','.join('?'*len(cols))),[[str(row[c]) for c in cols] for row in data])
 db.execute('CREATE INDEX idx_activities_city_cat ON activities(city,category)');db.execute('CREATE INDEX idx_interactions_user ON interactions(user_id)');db.commit();db.close()
 report={'generated_at_utc':datetime.now(timezone.utc).isoformat(),'schema_version':'1.0','activities':len(final),'cities':sorted({x['city'] for x in final}),'city_count':len(set(x['city'] for x in final)),'categories':{c:sum(x['category']==c for x in final) for c in categories},'synthetic_users':len(users),'synthetic_interactions':len(interactions),'validation':{'missing_name':sum(not x['name'] for x in final),'missing_coordinates':sum(x['lat'] is None or x['lon'] is None for x in final),'duplicate_osm_ids':len(final)-len(set(x['activity_id'] for x in final)),'all_synthetic_flags_true':all(x['synthetic']=='true' for x in users+interactions),'cost_estimates_flagged':all(x['is_estimated'] in ('true','false') for x in final)},'overpass_queries':calls,'license':'ODbL 1.0 for OSM-derived data; synthetic files are CC0-style dataset artifacts.'}
 (OUT/'validation_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 (OUT/'SOURCES_LICENSE.md').write_text('''# Sources and license\n\n## Places\n`activities.csv` is derived from [OpenStreetMap](https://www.openstreetmap.org/) data obtained through Overpass API and, when Overpass was unavailable, the official OSM API map endpoint on the timestamp in `validation_report.json`. © OpenStreetMap contributors. It is made available under the [Open Data Commons Open Database License (ODbL) v1.0](https://opendatacommons.org/licenses/odbl/1-0/). Each record carries its OSM element URL and ID. If you publicly use, redistribute, or build a derivative database from this data, comply with ODbL attribution, notice, share-alike, and Produced Work requirements.\n\n## Synthetic data\n`users.csv` and `interactions.csv` are generated by this project; every row is marked `synthetic=true`. They do **not** describe people or actual visits. These project-created synthetic artifacts may be used under CC0 1.0 to the extent possible.\n\n## Estimates\nPrice columns are heuristic defaults, not scraped or verified admission prices. Rows where defaults are used have `is_estimated=true`. Check venue websites before planning.\n''',encoding='utf-8')
 (OUT/'README.md').write_text(f'''# Weekend Activity Planner — United States\n\nCompetition-ready seed data for a personalized weekend activity recommender. Generated **{report['generated_at_utc']}**. It contains **{len(final):,}** named OSM places across **{report['city_count']}** major US cities, plus 1,000 clearly marked synthetic user profiles and {len(interactions):,} correlated synthetic interactions.\n\n## Files\n- `activities.csv`: real, named mapped places; one OSM element per row after deduplication.\n- `users.csv`, `interactions.csv`: artificial ML training signals, all `synthetic=true`; preferences, budget, group, accessibility, city and indoor/outdoor fit drive sampling.\n- `activity_categories.csv`, `weather_suitability.csv`: semantics and simple context rules.\n- `weekend_activity_planner_us.sqlite`: same data in SQLite.\n- `data_dictionary.csv`, `validation_report.json`, `SOURCES_LICENSE.md`: schema, checks, provenance/license.\n- `scripts/build_weekend_activity_planner_us.py`: reproducible builder; `scripts/baseline_recommender.py`: starter.\n\n## Quick start\n```bash\npython scripts/baseline_recommender.py --city Seattle --budget 30 --weather rain --categories museum,gallery\n```\n\n## Important limits\nOSM is community-maintained: categories, accessibility, contact details and opening hours can be incomplete/outdated. City assignment uses collection bounding boxes rather than a reverse-geocoded municipal boundary. Coordinates for ways/relations are OSM centers and may not be entrances. Prices and durations are explicit heuristic estimates; never treat them as venue facts. Confirm availability, fees, safety, and accessibility with the venue. This is a point-in-time extract—not a complete US inventory.\n\n## License / attribution\nSee `SOURCES_LICENSE.md`; public use requires OSM attribution and ODbL compliance.\n''',encoding='utf-8')
 (OUT/'README_FA.md').write_text(f'''# برنامه‌ریز فعالیت آخرهفته — ایالات متحده\n\nاین بسته در {report['generated_at_utc']} ساخته شده و شامل **{len(final):,}** مکان نام‌دار واقعی از OpenStreetMap در **{report['city_count']}** کلان‌شهر آمریکا است. ۱٬۰۰۰ کاربر و {len(interactions):,} تعامل در فایل‌های مربوطه کاملاً مصنوعی‌اند و هر سطر `synthetic=true` دارد؛ آن‌ها رفتار افراد واقعی نیستند.\n\n## فایل‌ها\n`activities.csv` مکان‌ها؛ `users.csv` و `interactions.csv` دادهٔ آموزشی مصنوعی؛ `activity_categories.csv` و `weather_suitability.csv` قواعد کمکی؛ پایگاه `SQLite`؛ فرهنگ داده، گزارش اعتبارسنجی، مجوز و اسکریپت‌های بازتولید/نمونه نیز موجود است.\n\n## محدودیت‌های مهم\nدادهٔ OSM ممکن است ناقص یا قدیمی باشد. شهر بر اساس محدودهٔ برداشت تعیین شده و مختصات راه/رابطه مرکز هندسی OSM است، نه لزوماً ورودی. هزینه و مدت‌زمان، برآورد الگوریتمی‌اند و با `is_estimated` مشخص شده‌اند؛ پیش از برنامه‌ریزی سایت مکان را بررسی کنید. این برداشت نقطه‌ای و کاملِ همهٔ آمریکا نیست.\n\n## منبع و مجوز\nمکان‌ها: © OpenStreetMap contributors، تحت ODbL 1.0. الزامات attribution و ODbL را رعایت کنید؛ جزئیات در `SOURCES_LICENSE.md` است.\n''',encoding='utf-8')
 print(json.dumps({'activities':len(final),'users':len(users),'interactions':len(interactions),'cities':len(set(x['city'] for x in final))}))
if __name__=='__main__':main()
