#!/usr/bin/env python3
"""Transparent baseline: rank activities using city, price, category and weather fit."""
import argparse,csv
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--city',required=True);p.add_argument('--budget',type=float,default=30);p.add_argument('--weather',default='mild');p.add_argument('--categories',default='') ;p.add_argument('--top-k',type=int,default=10);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
prefs={x.strip().lower() for x in a.categories.split(',') if x.strip()}
weather={r['weather_condition']:r['preferred_indoor_outdoor'] for r in csv.DictReader(open(root/'weather_suitability.csv',encoding='utf-8'))}.get(a.weather,'mixed')
rows=[]
for x in csv.DictReader(open(root/'activities.csv',encoding='utf-8')):
 if x['city'].casefold()!=a.city.casefold():continue
 score=float(x['data_quality_score'])
 score+=2 if x['category'].lower() in prefs else 0
 score+=1 if weather=='mixed' or x['indoor_outdoor'] in (weather,'mixed') else 0
 score+=1 if float(x['estimated_cost_usd_max'])<=a.budget else -2
 rows.append((score,x))
for score,x in sorted(rows,key=lambda z:(-z[0],z[1]['name']))[:a.top_k]:
 print(f"{score:.2f}\t{x['name']} | {x['category']} | ${x['estimated_cost_usd_min']}-${x['estimated_cost_usd_max']} | {x['source_url']}")
