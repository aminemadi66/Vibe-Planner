# برنامه‌ریز فعالیت آخرهفته — ایالات متحده

این بسته در 2026-08-04T10:18:36.896526+00:00 ساخته شده و شامل **11,630** مکان نام‌دار واقعی از OpenStreetMap در **12** کلان‌شهر آمریکا است. ۱٬۰۰۰ کاربر و 15,695 تعامل در فایل‌های مربوطه کاملاً مصنوعی‌اند و هر سطر `synthetic=true` دارد؛ آن‌ها رفتار افراد واقعی نیستند.

## فایل‌ها
`activities.csv` مکان‌ها؛ `users.csv` و `interactions.csv` دادهٔ آموزشی مصنوعی؛ `activity_categories.csv` و `weather_suitability.csv` قواعد کمکی؛ پایگاه `SQLite`؛ فرهنگ داده، گزارش اعتبارسنجی، مجوز و اسکریپت‌های بازتولید/نمونه نیز موجود است.

## محدودیت‌های مهم
دادهٔ OSM ممکن است ناقص یا قدیمی باشد. شهر بر اساس محدودهٔ برداشت تعیین شده و مختصات راه/رابطه مرکز هندسی OSM است، نه لزوماً ورودی. هزینه و مدت‌زمان، برآورد الگوریتمی‌اند و با `is_estimated` مشخص شده‌اند؛ پیش از برنامه‌ریزی سایت مکان را بررسی کنید. این برداشت نقطه‌ای و کاملِ همهٔ آمریکا نیست.

## اجرای همزمان Flask و FastAPI
`app.py` (صفحات + `/api/weather`) و سرویس FastAPI در پوشهٔ
`Weekend_Activity_Planner_API_Final/` (آب‌وهوای واقعی + گوگل کلندر) دو پردازش
جدا هستند. حالا `app.py` مسیر پروژهٔ FastAPI رو خودش، نسبت به مسیر خودش،
محاسبه می‌کنه (دیگه مسیر هاردکدشدهٔ ویندوزی لازم نیست).

۱) نصب وابستگی‌های FastAPI (در محیط مجازی جدا، طبق README خودش):
```bash
cd Weekend_Activity_Planner_API_Final
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt   # ویندوز: .venv\Scripts\python.exe ...
cp .env.example .env
cd ..
```
۲) نصب وابستگی‌های Flask: `pip install -r requirements.txt`
۳) اجرا از ریشهٔ پروژه: `python app.py` — این هم FastAPI را روی پورت ۸۰۰۰ بالا می‌آورد (تا پاسخ `/health` صبر می‌کند) و هم Flask را روی پورت ۵۰۰۰.
۴) تست اتصال: `http://127.0.0.1:5000/test-api`

## منبع و مجوز
مکان‌ها: © OpenStreetMap contributors، تحت ODbL 1.0. الزامات attribution و ODbL را رعایت کنید؛ جزئیات در `SOURCES_LICENSE.md` است.
